package com.sptest.sptest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SptestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SptestApplication.class, args);
	}

}
