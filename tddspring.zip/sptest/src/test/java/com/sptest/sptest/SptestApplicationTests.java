package com.sptest.sptest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SptestApplicationTests {

	@Test
	void contextLoads() {
	}

}
